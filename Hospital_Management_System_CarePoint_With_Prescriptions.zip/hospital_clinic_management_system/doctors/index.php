<?php
require_once __DIR__.'/../includes/functions.php'; require_role(['admin','receptionist']);$title='Doctors';$rows=$pdo->query("SELECT * FROM doctors ORDER BY full_name")->fetchAll();require __DIR__.'/../includes/header.php'; ?>
<div class="section-heading"><div><h2>Doctor directory</h2><p class="muted">Manage doctors and their specialisations.</p></div><?php if(has_role(['admin'])): ?><a class="btn primary" href="create.php">+ Add doctor</a><?php endif; ?></div>
<div class="table-wrap"><table><thead><tr><th>Name</th><th>Specialisation</th><th>Phone</th><th>Email</th><th>Status</th><?php if(has_role(['admin'])):?><th>Action</th><?php endif;?></tr></thead><tbody>
<?php foreach($rows as $d): ?><tr><td><?= e($d['full_name']) ?></td><td><?= e($d['specialisation']) ?></td><td><?= e($d['phone']) ?></td><td><?= e($d['email']) ?></td><td><?= $d['is_active']?'Active':'Inactive' ?></td><?php if(has_role(['admin'])):?><td><a href="edit.php?id=<?= (int)$d['id'] ?>">Edit</a></td><?php endif;?></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="6" class="empty">No doctors registered.</td></tr><?php endif;?></tbody></table></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
