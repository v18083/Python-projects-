<?php
require_once __DIR__.'/../includes/functions.php';require_role(['admin']);$title='Add doctor';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$s=$pdo->prepare("INSERT INTO doctors(full_name,specialisation,phone,email) VALUES(?,?,?,?)");$s->execute([trim($_POST['full_name']),trim($_POST['specialisation']),trim($_POST['phone']),trim($_POST['email'])]);flash('Doctor added.');redirect('doctors/index.php');}
require __DIR__.'/../includes/header.php';?>
<div class="form-card"><h2>Doctor details</h2><form method="post"><?=csrf_field()?><div class="form-grid"><label>Full name *<input name="full_name" required></label><label>Specialisation *<input name="specialisation" required></label><label>Phone<input name="phone"></label><label>Email<input type="email" name="email"></label></div><div class="form-actions"><a class="btn secondary" href="index.php">Cancel</a><button class="btn primary">Save doctor</button></div></form></div>
<?php require __DIR__.'/../includes/footer.php';?>
