<?php
require_once __DIR__.'/../includes/functions.php'; require_role(['admin','receptionist','doctor']); $title='Patient record';$id=(int)($_GET['id']??0);$s=$pdo->prepare("SELECT * FROM patients WHERE id=?");$s->execute([$id]);$p=$s->fetch();if(!$p)exit('Patient not found.');
$rx=$pdo->prepare("SELECT pr.*,d.full_name doctor_name FROM prescriptions pr JOIN doctors d ON d.id=pr.doctor_id WHERE pr.patient_id=? ORDER BY pr.created_at DESC");
$rx->execute([$id]);$prescriptions=$rx->fetchAll();
require __DIR__.'/../includes/header.php'; ?>
<div class="form-card"><div class="section-heading"><h2><?= e($p['full_name']) ?></h2><span class="status"><?= e($p['patient_number']) ?></span></div><div class="detail-grid">
<div><small>Date of birth</small><strong><?= e($p['date_of_birth']?:'Not recorded') ?></strong></div><div><small>Gender</small><strong><?= e($p['gender']) ?></strong></div><div><small>Phone</small><strong><?= e($p['phone']?:'Not recorded') ?></strong></div><div><small>Email</small><strong><?= e($p['email']?:'Not recorded') ?></strong></div><div><small>Emergency contact</small><strong><?= e($p['emergency_contact']?:'Not recorded') ?></strong></div><div><small>Address</small><strong><?= e($p['address']?:'Not recorded') ?></strong></div></div><div class="section-heading" style="margin-top:24px"><div><h2>Prescriptions</h2><p class="muted">Medicine prescribed for this patient.</p></div><?php if(has_role(['admin','doctor'])): ?><a class="btn primary" href="<?= BASE_URL ?>/prescriptions/create.php?patient_id=<?= (int)$p['id'] ?>">+ Add prescription</a><?php endif; ?></div>
<div class="table-wrap"><table><thead><tr><th>Medicine</th><th>Dosage</th><th>Frequency</th><th>Duration</th><th>Prescribed by</th><th>Date</th></tr></thead><tbody>
<?php foreach($prescriptions as $r): ?><tr><td><?= e($r['medicine_name']) ?></td><td><?= e($r['dosage']) ?></td><td><?= e($r['frequency']) ?></td><td><?= e($r['duration']) ?></td><td><?= e($r['doctor_name']) ?></td><td><?= e(substr($r['created_at'],0,10)) ?></td></tr><?php endforeach; ?>
<?php if(!$prescriptions): ?><tr><td colspan="6" class="empty">No prescriptions recorded for this patient.</td></tr><?php endif; ?>
</tbody></table></div><a class="btn secondary" href="index.php">Back to patients</a></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
