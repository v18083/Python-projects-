<?php
require_once __DIR__.'/../includes/functions.php'; require_role(['admin','receptionist']); $title='Register patient'; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();
$name=trim($_POST['full_name']??''); $dob=$_POST['date_of_birth']?:null; $gender=$_POST['gender']??'Other'; $phone=trim($_POST['phone']??''); $email=trim($_POST['email']??''); $address=trim($_POST['address']??''); $emergency=trim($_POST['emergency_contact']??'');
if($name==='') $error='Full name is required.';
else {$number='PT'.date('ymd').strtoupper(bin2hex(random_bytes(2))); $s=$pdo->prepare("INSERT INTO patients(patient_number,full_name,date_of_birth,gender,phone,email,address,emergency_contact) VALUES(?,?,?,?,?,?,?,?)"); $s->execute([$number,$name,$dob,$gender,$phone,$email,$address,$emergency]); flash('Patient registered successfully.'); redirect('patients/index.php');}}
require __DIR__.'/../includes/header.php'; ?>
<div class="form-card"><h2>New patient details</h2><?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?><div class="form-grid">
<label>Full name *<input name="full_name" required></label><label>Date of birth<input type="date" name="date_of_birth"></label>
<label>Gender<select name="gender"><option>Female</option><option>Male</option><option>Other</option></select></label><label>Phone<input name="phone"></label>
<label>Email<input type="email" name="email"></label><label>Emergency contact<input name="emergency_contact"></label>
<label class="span-2">Address<textarea name="address" rows="2"></textarea></label></div>
<div class="form-actions"><a class="btn secondary" href="index.php">Cancel</a><button class="btn primary">Save patient</button></div></form></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
