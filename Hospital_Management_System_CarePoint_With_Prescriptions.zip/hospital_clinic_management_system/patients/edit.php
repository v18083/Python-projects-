<?php
require_once __DIR__.'/../includes/functions.php'; require_role(['admin','receptionist']); $title='Edit patient'; $id=(int)($_GET['id']??0);
$s=$pdo->prepare("SELECT * FROM patients WHERE id=?");$s->execute([$id]);$p=$s->fetch();if(!$p)exit('Patient not found.');
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$s=$pdo->prepare("UPDATE patients SET full_name=?,date_of_birth=?,gender=?,phone=?,email=?,address=?,emergency_contact=? WHERE id=?");$s->execute([trim($_POST['full_name']),$_POST['date_of_birth']?:null,$_POST['gender'],trim($_POST['phone']),trim($_POST['email']),trim($_POST['address']),trim($_POST['emergency_contact']),$id]);flash('Patient details updated.');redirect('patients/index.php');}
require __DIR__.'/../includes/header.php'; ?>
<div class="form-card"><h2>Edit <?= e($p['full_name']) ?></h2><form method="post"><?= csrf_field() ?><div class="form-grid">
<label>Full name<input name="full_name" required value="<?= e($p['full_name']) ?>"></label><label>Date of birth<input type="date" name="date_of_birth" value="<?= e($p['date_of_birth']) ?>"></label>
<label>Gender<select name="gender"><?php foreach(['Female','Male','Other'] as $g): ?><option <?= $p['gender']===$g?'selected':'' ?>><?= $g ?></option><?php endforeach; ?></select></label>
<label>Phone<input name="phone" value="<?= e($p['phone']) ?>"></label><label>Email<input type="email" name="email" value="<?= e($p['email']) ?>"></label><label>Emergency contact<input name="emergency_contact" value="<?= e($p['emergency_contact']) ?>"></label>
<label class="span-2">Address<textarea name="address"><?= e($p['address']) ?></textarea></label></div><div class="form-actions"><a class="btn secondary" href="index.php">Cancel</a><button class="btn primary">Update patient</button></div></form></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
