<?php
require_once __DIR__.'/../includes/functions.php'; require_role(['admin','receptionist','doctor']); $title='Patients';
$search=trim($_GET['q']??''); $like='%'.$search.'%';
$s=$pdo->prepare("SELECT * FROM patients WHERE full_name LIKE ? OR patient_number LIKE ? OR phone LIKE ? ORDER BY created_at DESC"); $s->execute([$like,$like,$like]); $rows=$s->fetchAll();
require __DIR__.'/../includes/header.php'; ?>
<div class="section-heading"><div><h2>Patient records</h2><p class="muted">Register, search and update patient details.</p></div><?php if(has_role(['admin','receptionist'])): ?><a class="btn primary" href="create.php">+ Register patient</a><?php endif; ?></div>
<form class="search-form" method="get"><input name="q" placeholder="Search name, patient number or phone" value="<?= e($search) ?>"><button class="btn secondary">Search</button></form>
<div class="table-wrap"><table><thead><tr><th>Patient No.</th><th>Full name</th><th>Gender</th><th>Phone</th><th>Actions</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?= e($r['patient_number']) ?></td><td><?= e($r['full_name']) ?></td><td><?= e($r['gender']) ?></td><td><?= e($r['phone']) ?></td><td><a href="view.php?id=<?= (int)$r['id'] ?>">View</a> <?php if(has_role(['admin','receptionist'])): ?>· <a href="edit.php?id=<?= (int)$r['id'] ?>">Edit</a><?php endif; ?>
<?php if(has_role(['admin','doctor'])): ?>· <a href="<?= BASE_URL ?>/prescriptions/create.php?patient_id=<?= (int)$r['id'] ?>">Add prescription</a><?php endif; ?></td></tr><?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="5" class="empty">No patients found.</td></tr><?php endif; ?></tbody></table></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
