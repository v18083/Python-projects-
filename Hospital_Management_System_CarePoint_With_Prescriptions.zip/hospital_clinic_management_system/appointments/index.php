<?php
require_once __DIR__.'/../includes/functions.php';require_role(['admin','receptionist','doctor']);$title='Appointments';
$sql="SELECT a.*,p.full_name patient_name,d.full_name doctor_name FROM appointments a JOIN patients p ON p.id=a.patient_id JOIN doctors d ON d.id=a.doctor_id";$args=[];
if(has_role(['doctor'])){$sql.=" WHERE a.doctor_id=?";$args[]=(int)current_user()['doctor_id'];}
$sql.=" ORDER BY a.appointment_date DESC,a.appointment_time DESC";$s=$pdo->prepare($sql);$s->execute($args);$rows=$s->fetchAll();require __DIR__.'/../includes/header.php';?>
<div class="section-heading"><div><h2>Appointment schedule</h2><p class="muted">Manage patient visits and appointment status.</p></div><?php if(has_role(['admin','receptionist'])):?><a class="btn primary" href="create.php">+ Book appointment</a><?php endif;?></div>
<div class="table-wrap"><table><thead><tr><th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th><th>Reason</th><th>Status</th><?php if(has_role(['admin','receptionist'])):?><th>Update</th><?php endif;?></tr></thead><tbody>
<?php foreach($rows as $a):?><tr><td><?=e($a['patient_name'])?></td><td><?=e($a['doctor_name'])?></td><td><?=e($a['appointment_date'])?></td><td><?=e(substr($a['appointment_time'],0,5))?></td><td><?=e($a['reason'])?></td><td><?=e(ucfirst($a['status']))?></td><?php if(has_role(['admin','receptionist'])):?><td><a href="edit.php?id=<?=(int)$a['id']?>">Edit</a></td><?php endif;?></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="7" class="empty">No appointments found.</td></tr><?php endif;?></tbody></table></div>
<?php require __DIR__.'/../includes/footer.php';?>
