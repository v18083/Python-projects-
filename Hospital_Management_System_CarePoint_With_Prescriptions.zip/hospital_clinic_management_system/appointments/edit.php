<?php
require_once __DIR__.'/../includes/functions.php';require_role(['admin','receptionist']);$title='Update appointment';$id=(int)($_GET['id']??0);$s=$pdo->prepare("SELECT * FROM appointments WHERE id=?");$s->execute([$id]);$a=$s->fetch();if(!$a)exit('Appointment not found.');
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$status=$_POST['status'];$s=$pdo->prepare("UPDATE appointments SET status=? WHERE id=?");$s->execute([$status,$id]);flash('Appointment status updated.');redirect('appointments/index.php');}
require __DIR__.'/../includes/header.php';?>
<div class="form-card"><h2>Update appointment status</h2><p><?=e($a['appointment_date'].' at '.substr($a['appointment_time'],0,5))?></p><form method="post"><?=csrf_field()?><label>Status<select name="status"><?php foreach(['scheduled','completed','cancelled'] as $st):?><option value="<?=$st?>" <?=$a['status']===$st?'selected':''?>><?=ucfirst($st)?></option><?php endforeach;?></select></label><div class="form-actions"><a class="btn secondary" href="index.php">Cancel</a><button class="btn primary">Save status</button></div></form></div>
<?php require __DIR__.'/../includes/footer.php';?>
