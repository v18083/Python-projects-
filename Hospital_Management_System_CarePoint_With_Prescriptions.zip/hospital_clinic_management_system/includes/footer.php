</section>
<footer class="footer">CarePoint Clinic Management System · Academic project demonstration</footer>
</main></div>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body></html>
