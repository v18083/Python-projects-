<?php
require_once __DIR__ . '/functions.php';
require_login();
$title = $title ?? 'Dashboard';
$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= page_title($title) ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="app-shell">
<aside class="sidebar">
  <div class="brand"><img src="<?= BASE_URL ?>/assets/images/logo.png" alt="Hospital logo" class="hospital-logo"><div><strong>CarePoint</strong><small>Hospital Management</small></div></div>
  <div class="nav-label">MAIN MENU</div>
  <nav>
    <a class="nav-link <?= $title==='Dashboard'?'active':'' ?>" href="<?= BASE_URL ?>/dashboard.php"><span class="nav-icon">▦</span> Dashboard</a>
    <?php if (has_role(['admin','receptionist','doctor'])): ?><a class="nav-link <?= $title==='Patients'?'active':'' ?>" href="<?= BASE_URL ?>/patients/index.php"><span class="nav-icon">♙</span> Patients</a><?php endif; ?>
    <?php if (has_role(['admin','receptionist'])): ?><a class="nav-link <?= $title==='Doctors'?'active':'' ?>" href="<?= BASE_URL ?>/doctors/index.php"><span class="nav-icon">⚕</span> Doctors</a><?php endif; ?>
    <?php if (has_role(['admin','receptionist','doctor'])): ?><a class="nav-link <?= $title==='Appointments'?'active':'' ?>" href="<?= BASE_URL ?>/appointments/index.php"><span class="nav-icon">▣</span> Appointments</a><?php endif; ?>
    <?php if (has_role(['admin','doctor'])): ?><a class="nav-link <?= $title==='Prescriptions'?'active':'' ?>" href="<?= BASE_URL ?>/prescriptions/index.php"><span class="nav-icon">▤</span> Prescriptions</a><?php endif; ?>
    <?php if (has_role(['admin'])): ?><a class="nav-link" href="<?= BASE_URL ?>/users/index.php"><span class="nav-icon">⚙</span> User management</a><?php endif; ?>
  </nav>
  <div class="nav-label nav-label-bottom">ACCOUNT</div>
  <div class="sidebar-bottom"><small>Signed in as</small><strong><?= e(current_user()['full_name']) ?></strong><span class="role"><?= e(ucfirst(current_user()['role'])) ?></span><a href="<?= BASE_URL ?>/logout.php">↪ Sign out</a></div>
</aside>
<main class="main">
<header class="topbar"><div class="top-search"><span>⌕</span><input type="search" placeholder="Search records..." aria-label="Search records"></div><div class="top-actions"><span class="top-date"><?= date('D, d M Y') ?></span><div class="user-chip"><span class="avatar"><?= strtoupper(substr(current_user()['full_name'],0,1)) ?></span><span><?= e(current_user()['full_name']) ?></span></div></div></header>
<div class="page-heading"><div><span class="eyebrow">HOSPITAL MANAGEMENT</span><h1><?= e($title) ?></h1></div><span class="welcome-note">Welcome back, <?= e(current_user()['full_name']) ?></span></div>
<?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<section class="content">
