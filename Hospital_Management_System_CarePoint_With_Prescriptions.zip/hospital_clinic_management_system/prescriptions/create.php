<?php
require_once __DIR__.'/../includes/functions.php';
require_role(['admin','doctor']);
$title='Record prescription';
$isAdmin = has_role(['admin']);
$doctorId = $isAdmin ? 0 : (int)(current_user()['doctor_id'] ?? 0);
if (!$isAdmin && !$doctorId) exit('This doctor account is not linked to a doctor profile. Ask the administrator to link it.');

$patients = $pdo->query("SELECT id, full_name, patient_number FROM patients ORDER BY full_name")->fetchAll();
$doctors = $pdo->query("SELECT id, full_name, specialisation FROM doctors WHERE is_active=1 ORDER BY full_name")->fetchAll();
$selectedPatient = (int)($_GET['patient_id'] ?? 0);
$selectedDoctor = $isAdmin ? (int)($_POST['doctor_id'] ?? $_GET['doctor_id'] ?? 0) : $doctorId;
$errors = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $patientId = (int)($_POST['patient_id'] ?? 0);
    $medicine = trim($_POST['medicine_name'] ?? '');
    $dosage = trim($_POST['dosage'] ?? '');
    $frequency = trim($_POST['frequency'] ?? '');
    $duration = trim($_POST['duration'] ?? '');
    $instructions = trim($_POST['instructions'] ?? '');
    $appointmentId = (int)($_POST['appointment_id'] ?? 0) ?: null;
    $selectedPatient = $patientId;
    if ($isAdmin) $selectedDoctor = (int)($_POST['doctor_id'] ?? 0);

    if (!$patientId || !$selectedDoctor || !$medicine || !$dosage || !$frequency || !$duration) {
        $errors = 'Please complete all required prescription fields.';
    } else {
        $check = $pdo->prepare("SELECT id FROM patients WHERE id=?");
        $check->execute([$patientId]);
        $patientExists = $check->fetchColumn();
        $check = $pdo->prepare("SELECT id FROM doctors WHERE id=? AND is_active=1");
        $check->execute([$selectedDoctor]);
        $doctorExists = $check->fetchColumn();
        if (!$patientExists || !$doctorExists) {
            $errors = 'Please select a valid patient and doctor.';
        } else {
            if ($appointmentId) {
                $check = $pdo->prepare("SELECT id FROM appointments WHERE id=? AND patient_id=? AND doctor_id=?");
                $check->execute([$appointmentId, $patientId, $selectedDoctor]);
                if (!$check->fetchColumn()) $appointmentId = null;
            }
            $insert = $pdo->prepare("INSERT INTO prescriptions
                (patient_id, doctor_id, appointment_id, medicine_name, dosage, frequency, duration, instructions)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $insert->execute([$patientId, $selectedDoctor, $appointmentId, $medicine, $dosage, $frequency, $duration, $instructions]);
            flash('Prescription recorded successfully.');
            redirect('prescriptions/index.php');
        }
    }
}

$appointments = [];
if ($selectedDoctor && $selectedPatient) {
    $q = $pdo->prepare("SELECT id, appointment_date, appointment_time FROM appointments
        WHERE doctor_id=? AND patient_id=? ORDER BY appointment_date DESC, appointment_time DESC");
    $q->execute([$selectedDoctor, $selectedPatient]);
    $appointments = $q->fetchAll();
}
require __DIR__.'/../includes/header.php';
?>
<div class="form-card">
  <h2>Prescription details</h2>
  <?php if ($errors): ?><div class="alert error"><?= e($errors) ?></div><?php endif; ?>
  <form method="post">
    <?= csrf_field() ?>
    <div class="form-grid">
      <label>Patient *
        <select name="patient_id" required>
          <option value="">Select patient</option>
          <?php foreach ($patients as $patient): ?>
            <option value="<?= (int)$patient['id'] ?>" <?= $selectedPatient===(int)$patient['id']?'selected':'' ?>>
              <?= e($patient['full_name'].' ('.$patient['patient_number'].')') ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
      <?php if ($isAdmin): ?>
      <label>Prescribing doctor *
        <select name="doctor_id" required>
          <option value="">Select doctor</option>
          <?php foreach ($doctors as $doctor): ?>
            <option value="<?= (int)$doctor['id'] ?>" <?= $selectedDoctor===(int)$doctor['id']?'selected':'' ?>>
              <?= e($doctor['full_name'].' — '.$doctor['specialisation']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
      <?php else: ?>
        <input type="hidden" name="doctor_id" value="<?= $doctorId ?>">
      <?php endif; ?>
      <label>Related appointment
        <select name="appointment_id">
          <option value="">Not linked</option>
          <?php foreach ($appointments as $appointment): ?>
            <option value="<?= (int)$appointment['id'] ?>"><?= e($appointment['appointment_date'].' '.substr($appointment['appointment_time'],0,5)) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Medicine name *<input name="medicine_name" required></label>
      <label>Dosage *<input name="dosage" placeholder="e.g. 1 tablet" required></label>
      <label>Frequency *<input name="frequency" placeholder="e.g. Twice daily" required></label>
      <label>Duration *<input name="duration" placeholder="e.g. 5 days" required></label>
      <label class="span-2">Instructions for patient<textarea name="instructions" rows="3"></textarea></label>
    </div>
    <div class="form-actions"><a class="btn secondary" href="index.php">Cancel</a><button class="btn primary" type="submit">Save prescription</button></div>
  </form>
</div>
<?php require __DIR__.'/../includes/footer.php'; ?>
