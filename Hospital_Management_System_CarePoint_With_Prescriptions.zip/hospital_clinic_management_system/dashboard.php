<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$title='Dashboard';
$patients=(int)$pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();
$doctors=(int)$pdo->query("SELECT COUNT(*) FROM doctors WHERE is_active=1")->fetchColumn();
$appointments=(int)$pdo->query("SELECT COUNT(*) FROM appointments")->fetchColumn();
$prescriptions=(int)$pdo->query("SELECT COUNT(*) FROM prescriptions")->fetchColumn();
$todayCount=(int)$pdo->query("SELECT COUNT(*) FROM appointments WHERE appointment_date=CURDATE() AND status='scheduled'")->fetchColumn();
if (has_role(['doctor']) && !empty(current_user()['doctor_id'])) {
 $q=$pdo->prepare("SELECT a.id,a.appointment_date,a.appointment_time,a.status,p.full_name patient_name,d.full_name doctor_name,d.specialisation FROM appointments a JOIN patients p ON p.id=a.patient_id JOIN doctors d ON d.id=a.doctor_id WHERE a.doctor_id=? AND a.appointment_date>=CURDATE() AND a.status='scheduled' ORDER BY a.appointment_date,a.appointment_time LIMIT 5");
 $q->execute([current_user()['doctor_id']]);
} else {
 $q=$pdo->query("SELECT a.id,a.appointment_date,a.appointment_time,a.status,p.full_name patient_name,d.full_name doctor_name,d.specialisation FROM appointments a JOIN patients p ON p.id=a.patient_id JOIN doctors d ON d.id=a.doctor_id WHERE a.appointment_date>=CURDATE() AND a.status='scheduled' ORDER BY a.appointment_date,a.appointment_time LIMIT 5");
}
$upcoming=$q->fetchAll();
$dept=$pdo->query("SELECT specialisation,COUNT(*) total FROM doctors WHERE is_active=1 GROUP BY specialisation ORDER BY total DESC LIMIT 5")->fetchAll();
$recentRx=$pdo->query("SELECT pr.medicine_name,pr.created_at,p.full_name patient_name FROM prescriptions pr JOIN patients p ON p.id=pr.patient_id ORDER BY pr.created_at DESC LIMIT 3")->fetchAll();
$doctorSql="SELECT full_name,specialisation FROM doctors WHERE is_active=1 ORDER BY full_name LIMIT 4";
$doctorList=$pdo->query($doctorSql)->fetchAll();
require __DIR__.'/includes/header.php';
?>
<div class="care-stats">
 <article class="care-stat featured"><div><span>♙ &nbsp;Total Doctors</span><strong><?= $doctors ?></strong></div><small>↗ Active medical staff</small></article>
 <article class="care-stat"><div><span>▣ &nbsp;Total Patient</span><strong><?= $patients ?></strong></div><small class="positive">↗ Registered patient records</small></article>
 <article class="care-stat"><div><span>⚕ &nbsp;Total Prescriptions</span><strong><?= $prescriptions ?></strong></div><small>Prescription records</small></article>
 <article class="care-stat"><div><span>▦ &nbsp;Total Appointment</span><strong><?= $appointments ?></strong></div><small class="positive">↗ <?= $todayCount ?> scheduled today</small></article>
</div>
<div class="care-grid care-grid-top">
 <section class="care-card care-appointments"><div class="care-card-head"><h2>Appointment</h2><a href="<?= BASE_URL ?>/appointments/index.php">View all</a></div>
 <?php if($upcoming): foreach($upcoming as $a): ?><div class="care-appointment"><span class="care-person-icon">✚</span><div class="care-person"><strong><?= e($a['doctor_name']) ?></strong><small><?= e($a['specialisation']) ?> · <?= e($a['patient_name']) ?></small></div><div class="care-time"><small><?= e(date('d M',strtotime($a['appointment_date']))) ?></small><strong><?= e(substr($a['appointment_time'],0,5)) ?></strong></div></div><?php endforeach; else: ?><div class="care-empty">No upcoming appointments scheduled.</div><?php endif; ?>
 </section>
 <section class="care-card"><div class="care-card-head"><h2>Appointment Overview</h2><a href="<?= BASE_URL ?>/appointments/index.php">Details</a></div><div class="overview-ring"><div><strong><?= $todayCount ?></strong><small>Today</small></div></div><div class="ring-legend"><span><i class="dot-blue"></i> Scheduled</span><span><i class="dot-green"></i> Today</span></div><div class="overview-foot">Appointments are taken from your hospital records.</div></section>
 <section class="care-card"><div class="care-card-head"><h2>Doctor Specialities</h2><a href="<?= BASE_URL ?>/doctors/index.php">Details</a></div>
 <?php if($dept): $maxDept=max(array_column($dept,'total')); foreach($dept as $d): ?><div class="dept-row"><div><span><?= e($d['specialisation']) ?></span><strong><?= (int)$d['total'] ?></strong></div><div class="dept-track"><i style="width:<?= (int)round($d['total']/$maxDept*100) ?>%"></i></div></div><?php endforeach; else: ?><div class="care-empty">No active doctor specialities yet.</div><?php endif; ?>
 </section>
</div>
<div class="care-grid care-grid-bottom">
 <section class="care-card"><div class="care-card-head"><h2>Hospital Records</h2><span class="care-muted">Current totals</span></div><div class="record-bars"><div><span>Patients</span><strong><?= $patients ?></strong><i><b style="width:<?= $patients+$doctors+$prescriptions ? round($patients/max($patients,$doctors,$prescriptions,1)*100):0 ?>%"></b></i></div><div><span>Doctors</span><strong><?= $doctors ?></strong><i><b style="width:<?= round($doctors/max($patients,$doctors,$prescriptions,1)*100) ?>%"></b></i></div><div><span>Prescriptions</span><strong><?= $prescriptions ?></strong><i><b style="width:<?= round($prescriptions/max($patients,$doctors,$prescriptions,1)*100) ?>%"></b></i></div></div><div class="record-foot"><a href="<?= BASE_URL ?>/patients/index.php">Patients</a><a href="<?= BASE_URL ?>/prescriptions/index.php">Prescriptions</a></div></section>
 <section class="care-card"><div class="care-card-head"><h2>Recent Prescriptions</h2><a href="<?= BASE_URL ?>/prescriptions/index.php">View all</a></div><?php if($recentRx): foreach($recentRx as $rx): ?><div class="care-report"><span class="report-symbol">✚</span><div><strong><?= e($rx['medicine_name']) ?></strong><small><?= e($rx['patient_name']) ?> · <?= e(date('d M, H:i',strtotime($rx['created_at']))) ?></small></div></div><?php endforeach; else: ?><div class="care-empty">No prescriptions have been recorded.</div><?php endif; ?></section>
 <section class="care-card"><div class="care-card-head"><h2>Doctors List</h2><a href="<?= BASE_URL ?>/doctors/index.php">View all</a></div><?php if($doctorList): foreach($doctorList as $d): ?><div class="care-doctor"><span class="doctor-avatar">⚕</span><div><strong><?= e($d['full_name']) ?></strong><small><?= e($d['specialisation']) ?></small></div></div><?php endforeach; else: ?><div class="care-empty">No doctors added yet.</div><?php endif; ?></section>
</div>
<?php require __DIR__.'/includes/footer.php'; ?>
