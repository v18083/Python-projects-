<?php
require_once __DIR__ . '/includes/functions.php';
if (is_logged_in()) redirect('dashboard.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT id, username, password_hash, full_name, role, doctor_id FROM users WHERE username=? AND is_active=1 LIMIT 1");
    $stmt->execute([$username]); $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        unset($user['password_hash']);
        $_SESSION['user'] = $user;
        redirect('dashboard.php');
    }
    $error = 'Incorrect username or password.';
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Sign in | CarePoint</title><link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css"></head>
<body class="login-page"><div class="login-card">
<div class="login-logo"><img src="<?= BASE_URL ?>/assets/images/logo.png" alt="Hospital logo"></div><span class="eyebrow">10 MILES CAMPUS</span><h1>Welcome back</h1><p class="muted">Sign in to the Clinic Management System</p>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?><label>Username<input name="username" required autocomplete="username"></label>
<label>Password<div class="password-wrap"><input id="password" type="password" name="password" required autocomplete="current-password"><button type="button" class="toggle-password" data-toggle="password">Show</button></div></label>
<button class="btn primary full" type="submit">Sign in</button></form>
<p class="hint">Demo administrator: <strong>admin</strong> / <strong>Admin@123</strong></p>
</div><script src="<?= BASE_URL ?>/assets/js/app.js"></script></body></html>
