# Hospital / Clinic Management System

A PHP + MySQL web application built to match the supplied 10 Miles Campus project specification.

## Requirements
- PHP 8.0+
- MySQL 5.7+ / MariaDB
- Apache (XAMPP is suitable)
- A modern browser

## Installation
1. Copy the `hospital_clinic_management_system` folder into your web server's document root (for XAMPP: `htdocs`).
2. Start Apache and MySQL.
3. Open phpMyAdmin and import `database/hospital_management.sql`.
4. Edit `config/database.php` if your MySQL username/password differs from the defaults.
5. Visit `http://localhost/hospital_clinic_management_system/`.
6. Sign in with the initial administrator:
   - Username: `admin`
   - Password: `Admin@123`
7. Change the administrator password after signing in. Use **Users** to create receptionist and doctor accounts.

## Important setup note
The database import creates the administrator account with a PHP-compatible password hash for `Admin@123`.
This is a classroom/demo starter. Use fictional patient information for demonstrations. Do not deploy it with real patient data without a professional security, privacy, backup and hosting review.

## Roles
- **Administrator:** dashboard, users, patients, doctors, appointments, prescriptions.
- **Receptionist:** dashboard, patients, doctors (view), appointments.
- **Doctor:** dashboard, own appointments, patient records (view), prescriptions.

## Main folders
- `config/` database connection and application settings
- `includes/` shared header, footer, authentication and helpers
- `assets/` CSS and JavaScript
- `database/` SQL schema and seed administrator
- `patients/`, `doctors/`, `appointments/`, `prescriptions/`, `users/` modules
