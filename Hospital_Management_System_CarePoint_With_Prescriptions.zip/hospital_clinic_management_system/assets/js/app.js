document.addEventListener('click', function (event) {
  const button = event.target.closest('[data-toggle]');
  if (button) {
    const input = document.getElementById(button.dataset.toggle);
    if (input) { input.type = input.type === 'password' ? 'text' : 'password'; button.textContent = input.type === 'password' ? 'Show' : 'Hide'; }
  }
});
document.addEventListener('DOMContentLoaded', function () {
  const role = document.getElementById('role');
  const doctorField = document.getElementById('doctor-field');
  function updateDoctorField() { if (role && doctorField) doctorField.style.display = role.value === 'doctor' ? 'grid' : 'none'; }
  if (role) { role.addEventListener('change', updateDoctorField); updateDoctorField(); }
});
